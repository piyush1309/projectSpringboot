package com.springboot.file.springbootfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootfileApplication.class, args);
	}

}
