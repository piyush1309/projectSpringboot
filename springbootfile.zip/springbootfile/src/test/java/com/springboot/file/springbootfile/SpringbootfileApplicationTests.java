package com.springboot.file.springbootfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
